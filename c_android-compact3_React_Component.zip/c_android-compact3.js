import React from 'react'

import './c_android-compact3.css'

const CAndroidCompact3 = (props) => {
  return (
    <div className="c_android-compact3-frame">
      <img
        src="./assets/1c47acffc19a0c94278e361eb1266c4c.svg"
        alt="rectangle"
        width={412}
        height={116}
        className="c_android-compact3-rectangle"
      />
      <img
        src="./assets/da80e86f833cbf192aef415d5dd21d72.png"
        alt="rectangle"
        width={90}
        height={90}
        className="c_android-compact3-rectangle1"
      />
      <img
        src="./assets/3e8a1bf61c81860d958c8c153e4796be.png"
        alt="rectangle"
        width={90}
        height={90}
        className="c_android-compact3-rectangle2"
      />
      <img
        src="./assets/707f6f0aefbfcabd23b7f0e672290671.png"
        alt="rectangle"
        width={412}
        height={581}
        className="c_android-compact3-rectangle3"
      />
      <img
        src="./assets/2783ae259f2b746e47c697a3f57394f3.png"
        alt="rectangle"
        width={100}
        height={100}
        className="c_android-compact3-rectangle4"
      />
    </div>
  )
}

export default CAndroidCompact3
