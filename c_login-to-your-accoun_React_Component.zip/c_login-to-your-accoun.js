import React from 'react'

import './c_login-to-your-accoun.css'

const CLoginToYourAccoun = (props) => {
  return (
    <div className="c_login-to-your-accoun-text">
      <p className="c_login-to-your-accoun-text1">Login to your Account</p>
    </div>
  )
}

export default CLoginToYourAccoun
