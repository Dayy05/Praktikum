import React from 'react'

import './c_android-compact2.css'

const CAndroidCompact2 = (props) => {
  return (
    <div className="c_android-compact2-frame">
      <div className="c_android-compact2-text">
        <p className="c_android-compact2-text1">Create your Account</p>
      </div>
      <img
        src="./assets/7b95e3d6ae47b96d1955e9ddb92c6478.png"
        alt="rectangle"
        width={178}
        height={165}
        className="c_android-compact2-rectangle"
      />
      <img
        src="./assets/a3bf9a03d4dc3a3f1aea008e2f018c15.png"
        alt="rectangle"
        width={31}
        height={31}
        className="c_android-compact2-rectangle1"
      />
    </div>
  )
}

export default CAndroidCompact2
